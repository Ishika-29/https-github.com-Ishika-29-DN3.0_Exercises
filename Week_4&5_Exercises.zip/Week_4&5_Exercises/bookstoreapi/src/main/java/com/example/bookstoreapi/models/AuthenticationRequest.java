package com.example.bookstoreapi.models;

public class AuthenticationRequest {
    private String username;
    private String password;

    // Getters and Setters
}